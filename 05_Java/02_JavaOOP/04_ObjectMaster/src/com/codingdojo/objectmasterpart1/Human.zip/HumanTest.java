package com.codingdojo.objectmasterpart1;

public class HumanTest {

	public static void main(String[] args) {
		Human kai = new Human();
		Human bob = new Human();
		
		kai.attack(bob);
		bob.getStat();
	}

}
