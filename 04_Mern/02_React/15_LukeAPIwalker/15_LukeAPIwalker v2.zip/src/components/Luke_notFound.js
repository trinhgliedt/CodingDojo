import React from "react";

export default function NotFound(){
    return ( 
        <div>
        <p>These aren't the droids you're looking for!</p>
        <img src="https://media.giphy.com/media/l2JJKs3I69qfaQleE/giphy.gif" 
        alt="What you're searching for doesn't exist"/>

      </div>
    );
}