import React from "react";

function Home(){
    return (
        <div>Welcome</div>
    );
}
export default Home;