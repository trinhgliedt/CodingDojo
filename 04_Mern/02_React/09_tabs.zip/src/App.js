import React, {useState} from 'react';
// import logo from './logo.svg';
import './App.css';

// import PersonCard from "./components/PersonCard";
// import UserForm from "./components/HookForm";
// import BoxList from "./components/BoxGenerator";
import TabList from './components/Tabs';

function App() {
  return (
    <div className="App">
      <TabList/>
      
    </div>
  );
}

export default App;



{/* <PersonCard firstName="Jane" lastName="Doe" age={45} hairColor="Black"/>
      <PersonCard firstName="John" lastName="Smith" age={88} hairColor="Brown"/>
      <PersonCard firstName="Millard" lastName="Fillmore" age={50} hairColor="Brown"/>
    <PersonCard firstName="Maria" lastName="Smith" age={62} hairColor="Brown"/> */}
      
      {/* <UserForm>
      </UserForm> */}
      {/* <BoxList>

</BoxList> */}

      
