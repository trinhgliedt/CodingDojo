import React from 'react';
// import logo from './logo.svg';
// import Main from './views/Main';
import ProductForm from './components/ProductForm';

import './App.css';

function App() {
  return (
    <div className="App">
      <ProductForm />
    </div>
  );
}

export default App;
